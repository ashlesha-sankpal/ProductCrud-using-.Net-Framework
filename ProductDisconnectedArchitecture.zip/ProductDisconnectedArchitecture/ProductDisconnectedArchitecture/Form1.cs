﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductDisconnectedArchitecture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        MySqlConnection CN;
        MySqlDataAdapter DA;
        MySqlCommandBuilder CMD_BLD;
        DataSet DS;
       
            int currentIndex = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            CN=new MySqlConnection("Data source=192.168.100.80;port=3306;database=group004;user id=group004;password=welcome");
            DA=new MySqlDataAdapter("select * from product22",CN);
            CMD_BLD=new MySqlCommandBuilder(DA);
            DS= new DataSet();
            
            DA.Fill(DS, "product22");
            //dgvProducts.DataSource = DS.Tables[0];
            Navigate(currentIndex);

        }
        private void Navigate(int index)
        {
          if(DS.Tables[0].Rows.Count > 0)
            {
                txtid.Text=DS.Tables[0].Rows[index][0].ToString();
                txtname.Text = DS.Tables[0].Rows[index][1].ToString();
                txtcost.Text = DS.Tables[0].Rows[index][2].ToString();
                txtPdate.Text = DS.Tables[0].Rows[index][3].ToString();
                txtedate.Text = DS.Tables[0].Rows[index][4].ToString();

            }
        }

        private void btnfirst_Click(object sender, EventArgs e)
        {
            currentIndex = 0;
            Navigate(currentIndex);
        }

        private void btnlast_Click(object sender, EventArgs e)
        {
            currentIndex = DS.Tables[0].Rows.Count - 1; 
            Navigate(currentIndex);
        }

        private void btnpre_Click(object sender, EventArgs e)
        {
            if(currentIndex>0)
            {
                currentIndex--;
                Navigate(currentIndex);
            }
        }  

        private void btnnext_Click(object sender, EventArgs e)
        {
                if (currentIndex<DS.Tables[0].Rows.Count-1)
            {
                currentIndex++;
                Navigate(currentIndex);
            }
        
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtid.Text=String.Empty;
            txtname.Text=String.Empty;
            txtcost.Text=String.Empty;
            txtPdate.Text=String.Empty;
            txtedate.Text=String.Empty;
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            DataRow row=DS.Tables[0].NewRow();
            row["id"]=txtid.Text;
            row["name"]=txtname.Text;
            row["cost"]=txtcost.Text;
            row["pdate"]=txtPdate.Text;
            row["edate"]=txtedate.Text;
            DS.Tables[0].Rows.Add(row);
            DA.Update(DS.Tables[0]);

        }

        private void btnmodify_Click(object sender, EventArgs e)
        {
            DataRow row= DS.Tables[0].Rows[currentIndex];
            row["id"] = txtid.Text;
            row["name"] = txtname.Text;
            row["cost"] = txtcost.Text;
            row["pdate"] = txtPdate.Text;
            row["edate"] = txtedate.Text;
            DA.Update(DS.Tables[0]);
        }

        private void btnremove_Click(object sender, EventArgs e)
        {

            DS.Tables[0].Rows[currentIndex].Delete();
            DA.Update(DS.Tables[0]);
        }
    }
}
